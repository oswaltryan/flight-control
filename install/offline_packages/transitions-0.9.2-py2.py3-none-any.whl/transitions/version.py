"""Contains the current version of transition which is used in setup.py and can also be used
    to determine transitions' version during runtime.
"""

__version__ = '0.9.2'
