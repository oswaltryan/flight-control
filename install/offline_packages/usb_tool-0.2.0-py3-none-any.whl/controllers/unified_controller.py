# Directory: controllers
# Filename: unified_controller.py

#!/usr/bin/env python3

import json
import logging
import sys
import os
import time 
from typing import Optional, List, Dict, Any, Union, Tuple
import threading
from pprint import pprint
import subprocess

# --- Path Setup ---
CONTROLLERS_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CONTROLLERS_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

module_logger = logging.getLogger(__name__)

try:
    from controllers.phidget_board import PhidgetController, DEFAULT_SCRIPT_CHANNEL_MAP_CONFIG
    from controllers.logitech_webcam import (
        LogitechLedChecker, 
        DEFAULT_DURATION_TOLERANCE_SEC as CAMERA_DEFAULT_TOLERANCE,
        DEFAULT_REPLAY_POST_FAIL_DURATION_SEC as CAMERA_DEFAULT_REPLAY_DURATION, 
    )
    from controllers.barcode_scanner import BarcodeScanner
    from Phidget22.PhidgetException import PhidgetException
    from utils.led_states import LEDs
    from usb_tool import find_apricorn_device
    from transitions import EventData
except ImportError as e_import:
    module_logger.critical(f"Critical Import Error in unified_controller.py: {e_import}. Check paths and dependencies.", exc_info=True)
    raise


class UnifiedController:
    _phidget_controller: Optional[PhidgetController]
    _camera_checker: Optional[LogitechLedChecker]
    _barcode_scanner: Optional[BarcodeScanner]
    logger: logging.Logger
    phidget_config_to_use: Dict[str, Any]
    effective_led_duration_tolerance: float
    scanned_serial_number: Optional[str]

    def __init__(self,
                 script_map_config: Optional[Dict[str, Any]] = None,
                 camera_id: int = 0,
                 led_configs: Optional[Dict[str, Any]] = None,
                 display_order: Optional[List[str]] = None,
                 logger_instance: Optional[logging.Logger] = None,
                 led_duration_tolerance_sec: Optional[float] = None,
                 replay_post_failure_duration_sec: Optional[float] = None,
                 replay_output_dir: Optional[str] = None,
                 enable_instant_replay: Optional[bool] = None,
                 keypad_layout: Optional[Dict[str, Any]] = None):

        self.logger = logger_instance if logger_instance else module_logger
        
        # Initialize attributes early to guarantee their existence, even if None
        self._phidget_controller: Optional[PhidgetController] = None
        self._camera_checker: Optional[LogitechLedChecker] = None
        self._barcode_scanner: Optional[BarcodeScanner] = None
        self.scanned_serial_number: Optional[str] = None # Guaranteed to exist from the start
        self.is_fully_initialized: bool = False # Overall success flag

        phidget_init_successful = False
        camera_init_successful = False

        effective_replay_output_dir = replay_output_dir
        self.phidget_config_to_use = script_map_config if script_map_config is not None else DEFAULT_SCRIPT_CHANNEL_MAP_CONFIG
        phidget_ctrl_logger = self.logger.getChild("Phidget")
        camera_ctrl_logger = self.logger.getChild("Camera")

        # --- Initialize Phidget ---
        try:
            self._phidget_controller = PhidgetController(
                script_map_config=self.phidget_config_to_use, logger_instance=phidget_ctrl_logger)
            phidget_init_successful = True
        except Exception as e_phidget_init:
            self.logger.error(f"Failed to initialize PhidgetController: {e_phidget_init}", exc_info=True)

        # --- Initialize Camera ---
        self.effective_led_duration_tolerance = led_duration_tolerance_sec if led_duration_tolerance_sec is not None else CAMERA_DEFAULT_TOLERANCE
        effective_replay_duration = replay_post_failure_duration_sec if replay_post_failure_duration_sec is not None else CAMERA_DEFAULT_REPLAY_DURATION

        try:
            self._camera_checker = LogitechLedChecker(
                camera_id=camera_id, led_configs=led_configs, display_order=display_order,
                logger_instance=camera_ctrl_logger, duration_tolerance_sec=self.effective_led_duration_tolerance,
                replay_post_failure_duration_sec=effective_replay_duration, replay_output_dir=effective_replay_output_dir, enable_instant_replay=enable_instant_replay, keypad_layout=keypad_layout)
            if self._camera_checker.is_camera_initialized:
                camera_init_successful = True
            else:
                self.logger.error(f"LogitechLedChecker FAILED to initialize camera {camera_id}.")
        except Exception as e_camera_init:
            self.logger.error(f"Failed to initialize LogitechLedChecker for camera {camera_id}: {e_camera_init}", exc_info=True)

        # --- Initialize Barcode Scanner (no automatic scan on init) ---
        # Barcode scanner requires a phidget_press_callback, which uses self.press
        # If _phidget_controller failed, self.press will log an error.
        self._barcode_scanner = BarcodeScanner(phidget_press_callback=self.press)
        # self.scanned_serial_number remains None by default from early assignment.

        # Overall initialization status
        self.is_fully_initialized = phidget_init_successful and camera_init_successful

    # --- PhidgetController Method Delegation ---
    def on(self, *channel_names: str):
        if not self._phidget_controller: self.logger.error("Phidget not initialized for 'on' command."); return
        for channel_name in channel_names:
            # Visualize the start of the press
            if self._camera_checker:
                self._camera_checker.start_key_press_for_replay(channel_name)
            # Perform the physical action
            self._phidget_controller.on(channel_name)
    def off(self, *channel_names: str):
        if not self._phidget_controller: self.logger.error("Phidget not initialized for 'off' command."); return
        for channel_name in channel_names:
            # Visualize the end of the press
            if self._camera_checker:
                self._camera_checker.stop_key_press_for_replay(channel_name)
            # Perform the physical action
            self._phidget_controller.off(channel_name)
    def hold(self, channel_name: str, duration_ms: float = 200):
        if not self._phidget_controller: self.logger.error("Phidget not init for 'hold'."); return
        if self._camera_checker:
            self._camera_checker.log_key_press_for_replay(channel_name, duration_s=duration_ms / 1000.0)
        self._phidget_controller.hold(channel_name, duration_ms)
    def press(self, channel_or_channels: Union[str, List[str]], duration_ms: float = 100):
        if not self._phidget_controller: self.logger.error("Phidget not init for 'press'."); return
        if self._camera_checker:
            keys_to_log = [channel_or_channels] if isinstance(channel_or_channels, str) else channel_or_channels
            for key in keys_to_log:
                self._camera_checker.log_key_press_for_replay(key, duration_s=duration_ms / 1000.0)
        self._phidget_controller.press(channel_or_channels, duration_ms=duration_ms)
    def sequence(self, pin_sequence: List[Any], press_duration_ms: float = 100, pause_duration_ms: float = 100):
        if not self._phidget_controller: self.logger.error("Phidget not init for 'sequence'."); return
        if self._camera_checker:
            for item in pin_sequence:
                keys_to_log = [item] if isinstance(item, str) else item
                for key in keys_to_log:
                    self._camera_checker.log_key_press_for_replay(key, duration_s=press_duration_ms / 1000.0)
        self._phidget_controller.sequence(pin_sequence, press_ms=press_duration_ms, pause_ms=pause_duration_ms)
    def read_input(self, channel_name: str) -> Optional[bool]:
        if not self._phidget_controller: self.logger.error("Phidget not init for 'read_input'."); return None
        return self._phidget_controller.read_input(channel_name)
    def wait_for_input(self, channel_name: str, expected_state: bool, timeout_s: float = 5, poll_interval_s: float = 0.05) -> bool:
        if not self._phidget_controller: self.logger.error("Phidget not init for 'wait_for_input'."); return False
        return self._phidget_controller.wait_for_input(channel_name, expected_state, timeout_s, poll_interval_s)
    
    def scan_barcode(self) -> Optional[str]:
        """
        Triggers a new barcode scan and updates the controller's serial number.
        
        Returns:
            The scanned serial number string, or None if the scan failed or timed out.
        """
        if not self._barcode_scanner:
            self.logger.error("Barcode scanner not available.")
            return None
        
        self.logger.info("Triggering on-demand barcode scan...")
        scanned_data = self._barcode_scanner.await_scan()
        
        if scanned_data:
            self.logger.info(f"Successfully scanned new serial: {scanned_data}")
            self.scanned_serial_number = scanned_data
        else:
            self.logger.warning("On-demand barcode scan did not return data.")
            
        return scanned_data

    # --- LogitechLedChecker Method Delegation ---
    @property
    def is_camera_ready(self) -> bool:
        return self._camera_checker is not None and self._camera_checker.is_camera_initialized

    def confirm_led_solid(self, state: dict, minimum: float = 2, timeout: float = 10,
                                 fail_leds: Optional[List[str]] = None, clear_buffer: bool = True, 
                                 manage_replay: bool = True, replay_extra_context: Optional[Dict[str, Any]] = None) -> bool:
        checker = self._camera_checker
        if checker is None or not checker.is_camera_initialized:
            self.logger.error("Camera not ready for confirm_led_solid.")
            return False
        return checker.confirm_led_solid(state, minimum, timeout, fail_leds, clear_buffer, 
                                         manage_replay=manage_replay, replay_extra_context=replay_extra_context)

    def confirm_led_solid_strict(self, state: dict, minimum: float, clear_buffer: bool = True, 
                                 manage_replay: bool = True, replay_extra_context: Optional[Dict[str, Any]] = None) -> bool:
        checker = self._camera_checker
        if checker is None or not checker.is_camera_initialized:
            self.logger.error("Camera not ready for confirm_led_solid_strict.")
            return False
        return checker.confirm_led_solid_strict(state, minimum, clear_buffer, 
                                                manage_replay=manage_replay, replay_extra_context=replay_extra_context)

    def await_led_state(self, state: dict, timeout: float = 1,
                               fail_leds: Optional[List[str]] = None, clear_buffer: bool = True, 
                               manage_replay: bool = True, replay_extra_context: Optional[Dict[str, Any]] = None) -> bool:
        checker = self._camera_checker
        if checker is None or not checker.is_camera_initialized:
            self.logger.error("Camera not ready for await_led_state.")
            return False
        return checker.await_led_state(state, timeout, fail_leds, clear_buffer, 
                                       manage_replay=manage_replay, replay_extra_context=replay_extra_context)

    def confirm_led_pattern(self, pattern: list, clear_buffer: bool = True, 
                            manage_replay: bool = True, replay_extra_context: Optional[Dict[str, Any]] = None) -> bool:
        checker = self._camera_checker
        if checker is None or not checker.is_camera_initialized:
            self.logger.error("Camera not ready for confirm_led_pattern.")
            return False
        return checker.confirm_led_pattern(pattern, clear_buffer, 
                                           manage_replay=manage_replay, replay_extra_context=replay_extra_context)

    def await_and_confirm_led_pattern(self, pattern: list, timeout: float,
                                             clear_buffer: bool = True, manage_replay: bool = True, replay_extra_context: Optional[Dict[str, Any]] = None) -> bool:
        checker = self._camera_checker
        if checker is None or not checker.is_camera_initialized:
            self.logger.error("Camera not ready for await_and_confirm_led_pattern.")
            return False
        return checker.await_and_confirm_led_pattern(pattern, timeout, clear_buffer, 
                                                     manage_replay=manage_replay, replay_extra_context=replay_extra_context)

    # --- Resource Management ---
    def close(self):
        if self._camera_checker and hasattr(self._camera_checker, 'release_camera'):
            try: self._camera_checker.release_camera()
            except Exception as e: self.logger.error(f"Error releasing camera: {e}", exc_info=True)
        if self._phidget_controller and hasattr(self._phidget_controller, 'close_all'):
            try: self._phidget_controller.close_all()
            except Exception as e: self.logger.error(f"Error closing phidget: {e}", exc_info=True)
    def __enter__(self): return self
    def __exit__(self, exc_type, exc_val, exc_tb): self.close()

    def confirm_device_enum(self, serial_number: str, stable_min: float = 5, timeout: float = 15) -> Tuple[bool, Optional[Any]]:
        """
        Confirms a device is enumerated and stable in OOB/Standby mode (no data partition).
        
        Returns:
            A tuple containing:
            - bool: True if the device was found and stable, False otherwise.
            - Optional[ApricornDevice]: The device object if successful, else None.
        """
        self.logger.info(f"Confirming Device enumeration (stable: {stable_min}s, overall_timeout: {timeout}s)...")
        overall_start_time = time.time()
        
        # Use find_apricorn_device and handle the case where it returns an empty list
        devices = find_apricorn_device()
        if not devices:
            self.logger.warning("No device found on initial enum check.")
            return False, None
        
        DUT_ping_1 = None
        for device in devices:
            if device.iSerial == serial_number:
                DUT_ping_1 = device

        if DUT_ping_1 == None:
            self.logger.error(f"Could not match devices on bus with Serial Number...")
            return False, None
        
        first_device_serial = DUT_ping_1.iSerial
        if DUT_ping_1.driveSizeGB != "N/A (OOB Mode)":
            self.logger.warning(f"Device volume is exposed! Expected OOB/Standby mode.")
            return False, None
        else:
            self.logger.info(f"Initial device found with iSerial: {first_device_serial}. Verifying stability...")
        
        stability_wait_start = time.time()
        while time.time() - stability_wait_start < stable_min:
            if time.time() - overall_start_time > timeout:
                self.logger.warning(f"Overall timeout ({timeout}s) reached while waiting for stability for device {first_device_serial}.")
                return False, None
            time.sleep(0.2)

        devices_after_wait = find_apricorn_device()
        if not devices_after_wait:
            self.logger.warning(f"Device with iSerial {first_device_serial} disappeared after {time.time() - stability_wait_start:.2f}s stability wait.")
            return False, None
        
        DUT_ping_2 = None
        for device in devices_after_wait:
            if device.iSerial == serial_number:
                DUT_ping_2 = device

        if DUT_ping_2 == None:
            self.logger.error(f"Device is not stable on the bus...")
            return False, None

        if DUT_ping_2.driveSizeGB != "N/A (OOB Mode)":
            self.logger.warning(f"Device volume became exposed during stability wait!")
            pprint(DUT_ping_2)
            return False, None

        self.logger.info(f"Device with iSerial {first_device_serial} confirmed stable for at least {stable_min}s:")
        self.logger.info(f"  VID:PID  [Firm] @USB iSerial      iProduct")
        self.logger.info(f"  {DUT_ping_2.idVendor}:{DUT_ping_2.idProduct} [{DUT_ping_2.bcdDevice}] @{DUT_ping_2.bcdUSB} {DUT_ping_2.iSerial} {DUT_ping_2.iProduct}")
        return True, DUT_ping_2
    
    def confirm_drive_enum(self, serial_number: str, stable_min: float = 5, timeout: float = 15) -> Tuple[bool, Optional[Any]]:
        """
        Confirms a device's data partition is enumerated and stable.
        
        Returns:
            A tuple containing:
            - bool: True if the drive was found and stable, False otherwise.
            - Optional[ApricornDevice]: The device object if successful, else None.
        """
        self.logger.info(f"Confirming Drive enumeration (stable: {stable_min}s, overall_timeout: {timeout}s)...")
        overall_start_time = time.time()
        
        devices = find_apricorn_device()
        if not devices:
            self.logger.warning("No device found on initial enum check.")
            return False, None
        
        DUT_ping_1 = None
        for device in devices:
            if device.iSerial == serial_number:
                DUT_ping_1 = device

        if DUT_ping_1 == None:
            self.logger.error(f"Could not match devices on bus with Serial Number...")
            return False, None

        first_device_serial = DUT_ping_1.iSerial
        if DUT_ping_1.driveSizeGB == "N/A (OOB Mode)":
            self.logger.warning(f"Device volume is not exposed!")
            return False, None
        else:
            self.logger.info(f"Initial device found with iSerial: {first_device_serial}. Verifying stability...")
        
        stability_wait_start = time.time()
        while time.time() - stability_wait_start < stable_min:
            if time.time() - overall_start_time > timeout:
                self.logger.warning(f"Overall timeout ({timeout}s) reached while waiting for stability for device {first_device_serial}.")
                return False, None
            time.sleep(0.2)

        devices_after_wait = find_apricorn_device()
        if not devices_after_wait:
            self.logger.warning(f"Device with iSerial {first_device_serial} disappeared after {time.time() - stability_wait_start:.2f}s stability wait.")
            return False, None
        
        DUT_ping_2 = None
        for device in devices_after_wait:
            if device.iSerial == serial_number:
                DUT_ping_2 = device

        if DUT_ping_2 == None:
            self.logger.error(f"Device is not stable on the bus...")
            return False, None
        
        if DUT_ping_2.driveSizeGB == "N/A (OOB Mode)":
            self.logger.warning(f"Device volume disappeared during stability wait!")
            return False, None

        self.logger.info(f"Drive with iSerial {first_device_serial} confirmed stable for at least {stable_min}s:")
        self.logger.info(f"  VID:PID  [Firm] @USB iSerial      iProduct")
        self.logger.info(f"  {DUT_ping_2.idVendor}:{DUT_ping_2.idProduct} [{DUT_ping_2.bcdDevice}] @{DUT_ping_2.bcdUSB} {DUT_ping_2.iSerial} {DUT_ping_2.iProduct}")
        return True, DUT_ping_2
    
    def _get_fio_path(self) -> str:
        """
        Determines the correct path to the bundled FIO binary based on the OS.

        Returns:
            The absolute path to the FIO executable.

        Raises:
            FileNotFoundError: If the FIO binary for the current OS is not found.
            NotImplementedError: If the current OS is not supported.
        """
        # Assumes PROJECT_ROOT is defined at the top of the file
        binaries_dir = os.path.join(PROJECT_ROOT, 'utils', 'fio')
        fio_path = None

        if sys.platform == 'darwin':
            fio_path = os.path.join(binaries_dir, 'fio-macos')
        elif sys.platform.startswith('linux'):
            fio_path = os.path.join(binaries_dir, 'fio-linux')
        elif sys.platform == 'win32':
            fio_path = os.path.join(binaries_dir, 'fio-windows.exe')
        else:
            raise NotImplementedError(f"FIO automation is not supported on this OS: {sys.platform}")

        if not os.path.isfile(fio_path):
            raise FileNotFoundError(f"FIO executable not found at the expected path: {fio_path}")
        
        # On Linux/macOS, ensure it's executable
        if not os.access(fio_path, os.X_OK) and sys.platform != 'win32':
            self.logger.warning(f"FIO binary at {fio_path} is not executable. Attempting to run it anyway, but it may fail.")

        return fio_path
    
    def _parse_fio_json_output(self, json_output: str) -> Optional[Dict[str, float]]:
        """
        Parses the JSON output from FIO to extract read and write bandwidth.

        Args:
            json_output: The string containing the FIO JSON data.

        Returns:
            A dictionary with 'read' and/or 'write' keys and their speeds in MB/s,
            or None if parsing fails.
        """
        try:
            data = json.loads(json_output)
            results = {}
            # FIO output contains a list of jobs, we are interested in the first one.
            if 'jobs' in data and data['jobs']:
                job_result = data['jobs'][0]
                
                # Check for read results
                if 'read' in job_result and job_result['read']['io_bytes'] > 0:
                    bw_bytes = job_result['read']['bw_bytes']
                    # Convert Bytes/sec to Megabytes/sec (1 MB = 1,000,000 bytes)
                    results['read'] = round(bw_bytes / 1000**2, 2)

                # Check for write results
                if 'write' in job_result and job_result['write']['io_bytes'] > 0:
                    bw_bytes = job_result['write']['bw_bytes']
                    results['write'] = round(bw_bytes / 1000**2, 2)
                
                return results if results else None
            else:
                self.logger.warning("FIO JSON output is missing 'jobs' array.")
                return None
        except (json.JSONDecodeError, KeyError, IndexError) as e:
            self.logger.error(f"Failed to parse FIO JSON output: {e}", exc_info=True)
            return None

    def run_fio_tests(self, disk_path: str, duration: int = 10, tests_to_run: Optional[List[Dict[str, Any]]] = None) -> Optional[Dict[str, float]]:
        """
        Runs a series of specified FIO speed tests directly on the block device.

        Args:
            disk_path (str): The device path.
                             On Linux: e.g., '/dev/sdb'
                             On Windows: e.g., 'PhysicalDrive1'
            duration (int): The runtime in seconds for each test.
            tests_to_run (Optional[List[Dict]]): A list of dictionaries defining
                custom tests. If None, default tests are used.
        
        Returns:
            A single dictionary containing all results, or None if the sequence failed.
        """
        if tests_to_run is None:
            self.logger.debug("No specific tests provided, using default sequential R/W tests.")
            tests_to_run = [
                {
                    "name": "W-SEQ-1M-Q32",
                    "rw": "write",
                    "bs": "1m",
                    "iodepth": 32
                },
                {
                    "name": "R-SEQ-1M-Q32",
                    "rw": "read",
                    "bs": "1m",
                    "iodepth": 32
                }
            ]

        self.logger.debug(f"Starting FIO speed test sequence for {duration}s each.")
        
        try:
            fio_path = self._get_fio_path()
        except (FileNotFoundError, NotImplementedError) as e:
            self.logger.error(f"Cannot run FIO tests: {e}")
            raise
        
        if sys.platform == 'win32':
            disk_path_str = str(disk_path)
            # Check if the path is just a number (e.g., "3"). If so, prepend "PhysicalDrive".
            if disk_path_str.isdigit():
                win_path = f"PhysicalDrive{disk_path_str}"
            else:
                win_path = disk_path_str # Assume it's already correctly named "PhysicalDriveX"

            # For raw device access on Windows, the format is \\.\PhysicalDriveN
            fio_target_device = f"\\\\.\\{win_path}"
            self.logger.debug(f"Targeting raw Windows device: {fio_target_device}")
        else:
            # On Linux, the path is already in the correct format (e.g., /dev/sdb)
            fio_target_device = disk_path
            self.logger.debug(f"Targeting raw Linux device: {fio_target_device}")

        combined_results = {}

        for test_params in tests_to_run:
            self.logger.debug(f"--- Preparing FIO test: {test_params.get('name', 'Unnamed')} ---")
            
            base_command = [fio_path]

            if sys.platform.startswith('linux'):
                base_command.extend(["--ioengine=libaio"])
            elif sys.platform == 'win32':
                base_command.extend(["--ioengine=windowsaio", "--thread"])
            
            base_command.extend([
                "--direct=1",
                "--output-format=json",
                "--random_generator=tausworthe64",
                f"--filename={fio_target_device}", # Use the correctly formatted device path
                f"--runtime={duration}",
                f"--name={test_params.get('name')}",
                f"--rw={test_params.get('rw')}",
                f"--bs={test_params.get('bs')}",
                f"--iodepth={test_params.get('iodepth')}",
                "--group_reporting"
            ])
            
            try:
                self.logger.debug(f"Executing command: {' '.join(base_command)}")
                # IMPORTANT: FIO may require administrator/root privileges for raw device access.
                # The calling script should be run with sudo/as Administrator.
                result = subprocess.run(base_command, check=True, capture_output=True, text=True)
                
                parsed_result = self._parse_fio_json_output(result.stdout)
                if parsed_result:
                    self.logger.debug(f"--- FIO Test '{test_params.get('name')}' Result: {parsed_result} MB/s")
                    combined_results.update(parsed_result)
                else:
                    self.logger.error(f"Failed to parse results for FIO test '{test_params.get('name')}'.")
                    return None

                if result.stderr:
                    self.logger.warning(f"FIO Stderr: {result.stderr}")

            except FileNotFoundError:
                self.logger.error(f"FIO command not found at '{fio_path}'.")
                raise
            except subprocess.CalledProcessError as e:
                self.logger.error(f"FIO test '{test_params.get('name')}' failed with exit code {e.returncode}.")
                self.logger.error(f"  This can happen if the script is not run with administrator/root privileges.")
                self.logger.error(f"  Stdout: {e.stdout}")
                self.logger.error(f"  Stderr: {e.stderr}")
                return None
            except Exception as e:
                self.logger.error(f"An unexpected error occurred during FIO test: {e}", exc_info=True)
                return None
        
        self.logger.info(f"Read: {combined_results['read']}")
        self.logger.info(f"Write: {combined_results['write']}")
        self.logger.info("FIO test sequence completed successfully.")
        return combined_results

    # --- FSM Event Handling Callbacks (High-Level) ---
    def handle_post_failure(self, event_data: Any) -> None: 
        details = event_data.kwargs.get('details', "No details provided") if event_data and hasattr(event_data, 'kwargs') else "No details provided"
        self.logger.error(f"UnifiedController: Handling POST failure. Details from FSM: {details}")

    def handle_critical_error(self, event_data: Any) -> None:
        details = event_data.kwargs.get('details', "No details provided") if event_data and hasattr(event_data, 'kwargs') else "No details provided"
        self.logger.critical(f"UnifiedController: Handling CRITICAL error. Details from FSM: {details}")

# --- For direct testing ---
if __name__ == '__main__': # pragma: no cover
    try:
        from utils.logging_config import setup_logging
        setup_logging(default_log_level=logging.DEBUG) 
    except ImportError:
        logging.basicConfig(stream=sys.stdout, level=logging.DEBUG,
                            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        logging.getLogger().critical("Could not import 'utils.logging_config.setup_logging' for direct test. Using basicConfig.")

    direct_test_logger = logging.getLogger("UnifiedControllerDirectTest")
    direct_test_logger.info("UnifiedController direct test logging configured and starting...")
    uc_instance_for_test = None
    try:
        test_replay_dir = os.path.join(PROJECT_ROOT, "logs", "test_replays_uc_direct")
        os.makedirs(test_replay_dir, exist_ok=True)

        uc_instance_for_test = UnifiedController(
            logger_instance=direct_test_logger.getChild("TestUCInstance"),
            camera_id=0, 
            led_duration_tolerance_sec=0.08, 
            replay_post_failure_duration_sec=2.0, # Shorter for quick testing
            replay_output_dir=test_replay_dir 
        )
        direct_test_logger.info(f"Test UnifiedController instance created. Camera Ready: {uc_instance_for_test.is_camera_ready}")
        if uc_instance_for_test._camera_checker:
            direct_test_logger.info(f"  Replay dir: {uc_instance_for_test._camera_checker.replay_output_dir}")

        if uc_instance_for_test.is_camera_ready:
            direct_test_logger.info("--- Testing Camera Replay with Context ---")
            fail_state = {"red": 1, "green": 1, "blue": 1} # A state likely to fail
            
            # Simulate context that an FSM might provide
            test_context = {
                "replay_script_name": os.path.basename(__file__),
                "replay_fsm_test_case": "DirectUCTest_Failure",
                "replay_some_other_info": "Value123"
            }
            direct_test_logger.info(f"Attempting confirm_led_solid for {fail_state} (expecting failure and replay with context).")
            # input("Prepare for FAILING confirm_led_solid test with context. Press Enter...")
            
            uc_instance_for_test.confirm_led_solid(
                fail_state, minimum=0.1, timeout=0.5, replay_extra_context=test_context
            )
            direct_test_logger.info(f"  Check for replay video in: {test_replay_dir}")
        else:
            direct_test_logger.warning("Camera component not ready, skipping camera replay test.")
            
    except Exception as e_test_main:
        direct_test_logger.error(f"Error during UnifiedController direct test: {e_test_main}", exc_info=True)
    finally:
        if uc_instance_for_test:
            direct_test_logger.info("Closing UnifiedController instance from direct test...")
            uc_instance_for_test.close()
        direct_test_logger.info("UnifiedController direct test finished.")